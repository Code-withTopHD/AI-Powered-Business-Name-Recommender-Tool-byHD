import uvicorn
from fastapi.staticfiles import StaticFiles
from importlib.resources import files as pkg_files

from .api import app


# Mount static frontend at /
static_dir = str(pkg_files("name_recommender").joinpath("static"))
app.mount("/static", StaticFiles(directory=static_dir), name="static")


@app.get("/")
def index_redirect():
	return {
		"message": "Open /static/index.html for the UI or POST /generate to use the API",
		"ui": "/static/index.html",
		"api": "/generate",
	}


def run():
	uvicorn.run("name_recommender.__main__:app", host="0.0.0.0", port=8000, reload=False)


if __name__ == "__main__":
	run()


